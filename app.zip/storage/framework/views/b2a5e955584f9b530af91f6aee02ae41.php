

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1>Kontak Kami</h1>
    <p>Silakan hubungi kami melalui email <a href="mailto:support@sotnbus.com">support@sotnbus.com</a> atau nomor WhatsApp 0812-xxxx-xxxx.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sotnbus\resources\views\contact.blade.php ENDPATH**/ ?>