<nav class="bg-white shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
            <!-- Logo -->
            <div class="flex items-center space-x-3">
                <a href="<?php echo e(route('home')); ?>" class="flex items-center text-blue-600 font-bold text-lg">
                    <i class="fas fa-bus mr-2"></i>
                    <span>SOTNBUS.COM</span>
                </a>
            </div>

            <!-- Navigasi -->
            <div class="hidden md:flex space-x-6">
                <a href="<?php echo e(route('home')); ?>" class="text-gray-700 hover:text-blue-600 font-medium">Beranda</a>
                <a href="#" class="text-gray-700 hover:text-blue-600 font-medium">Tiket Bus</a>
                <a href="<?php echo e(route('promotions.index')); ?>" class="text-gray-700 hover:text-blue-600 font-medium">Promo</a>
                <a href="<?php echo e(route('contact')); ?>" class="text-gray-700 hover:text-blue-600 font-medium">Bantuan</a>
            </div>

            <!-- Autentikasi -->
            <div class="flex items-center space-x-4">
                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-blue-600 hover:underline text-sm font-semibold">Masuk</a>
                    <a href="<?php echo e(route('register')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded text-sm font-semibold hover:bg-blue-700 transition">Daftar</a>
                <?php else: ?>
                    <span class="text-sm text-gray-700">Hai, <?php echo e(Auth::user()->name); ?></span>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="text-sm text-red-600 hover:underline ml-2">Logout</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\laragon\www\sotnbus\resources\views\layouts\partials\navbar.blade.php ENDPATH**/ ?>