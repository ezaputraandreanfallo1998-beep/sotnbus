<footer class="bg-white text-center py-6 mt-10 shadow-inner">
    <p class="text-sm text-gray-500">© <?php echo e(date('Y')); ?> SOTNBUS. Semua Hak Dilindungi.</p>
</footer>
<?php /**PATH D:\laragon\www\sotnbus\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>