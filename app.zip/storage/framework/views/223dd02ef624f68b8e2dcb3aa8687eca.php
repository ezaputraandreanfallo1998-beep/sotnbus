<section class="relative bg-cover bg-center bg-no-repeat h-[450px] flex items-center justify-center text-center text-white" style="background-image: url('<?php echo e(asset('images/bus-hero.jpg')); ?>');">
    <div class="bg-black bg-opacity-50 w-full h-full absolute top-0 left-0"></div>
    <div class="z-10">
        <h1 class="text-4xl md:text-5xl font-bold mb-4">Pesan Tiket Bus Online dengan Mudah</h1>
        <p class="text-lg md:text-xl">Nikmati perjalanan nyaman dengan harga terjangkau ke berbagai kota di Indonesia</p>
    </div>
</section>
<?php /**PATH D:\laragon\www\sotnbus\resources\views\home\hero.blade.php ENDPATH**/ ?>