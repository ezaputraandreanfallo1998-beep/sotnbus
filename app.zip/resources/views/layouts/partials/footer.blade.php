<footer class="bg-white text-center py-6 mt-10 shadow-inner">
    <p class="text-sm text-gray-500">© {{ date('Y') }} SOTNBUS. Semua Hak Dilindungi.</p>
</footer>
