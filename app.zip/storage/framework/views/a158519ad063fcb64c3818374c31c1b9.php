<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Rute Bus Unggulan</h2>
    
    <?php $__currentLoopData = $featuredRoutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($route->origin->name); ?> → <?php echo e($route->destination->name); ?></h5>
                <p class="card-text">
                    Bus: <?php echo e($route->bus->name); ?><br>
                    Berangkat: <?php echo e($route->departure_time->format('d M Y H:i')); ?><br>
                    Harga: Rp <?php echo e(number_format($route->price, 0, ',', '.')); ?>

                </p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sotnbus\resources\views\home.blade.php ENDPATH**/ ?>