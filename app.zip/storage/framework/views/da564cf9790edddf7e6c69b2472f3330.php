<!DOCTYPE html>
<html>
<head>
    <title>SOTNBUS</title>
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
</head>
<body>
    <div class="header">
        <div class="navbar">
            <div class="container">
                <div class="logo">SOTNBUS</div>
                <ul class="nav">
                    <li><a href="#">Beranda</a></li>
                    <li><a href="#">Pesan Tiket</a></li>
                    <li><a href="#">Tentang</a></li>
                    <li><a href="#">Kontak</a></li>
                </ul>
            </div>
        </div>

        <div class="banner">
            <img class="img" src="<?php echo e(asset('images/banner3.jpg')); ?>">
        </div>
    </div>

    <div class="content">
        <h1 class="center">FITUR UNGGULAN</h1>
        <div class="row">
            <div class="col">
                <img class="img" src="<?php echo e(asset('images/bus3.jpg')); ?>">
                <h3>Rute Fleksibel</h3>
                <p>Tentukan rute perjalanan bus Anda sendiri, sesuai kebutuhan Anda.</p>
            </div>
            <div class="col">
                <img class="img" src="<?php echo e(asset('images/bus2.jpg')); ?>">
                <h3>Pilih Kursi Sendiri</h3>
                <p>Pilih kursi yang diinginkan di dalam bus sesuai kenyamanan Anda.</p>
            </div>
            <div class="col">
                <img class="img" src="<?php echo e(asset('images/bus4.jpg')); ?>">
                <h3>QRIS Pembayaran</h3>
                <p>Pembayaran mudah dengan scan QR Code untuk semua dompet digital.</p>
            </div>
        </div>
    </div>

    <footer>
        <p>© <?php echo e(date('Y')); ?> SOTNBUS. Semua Hak Dilindungi.</p>
    </footer>
</body>
</html>
<?php /**PATH D:\laragon\www\sotnbus\resources\views/home.blade.php ENDPATH**/ ?>