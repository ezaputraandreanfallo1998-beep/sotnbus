<nav class="fixed w-full bg-white shadow z-50">
    <div class="container mx-auto px-4 py-3 flex justify-between items-center">
        <a href="<?php echo e(route('home')); ?>" class="text-xl font-bold text-orange-600">SOTNBUS</a>

        <div class="space-x-4">
            <a href="<?php echo e(route('home')); ?>"
               class="<?php echo e(request()->routeIs('home') ? 'text-orange-600 font-semibold' : 'text-gray-700'); ?> hover:text-orange-600">
                Beranda
            </a>

            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('dashboard')); ?>" class="text-gray-700 hover:text-orange-600">Dashboard</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                    <?php echo csrf_field(); ?>
                    <button class="text-gray-700 hover:text-red-600">Keluar</button>
                </form>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-gray-700 hover:text-orange-600">Masuk</a>
                <a href="<?php echo e(route('register')); ?>" class="text-gray-700 hover:text-orange-600">Daftar</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH D:\laragon\www\sotnbus\resources\views/layouts/partials/navbar.blade.php ENDPATH**/ ?>