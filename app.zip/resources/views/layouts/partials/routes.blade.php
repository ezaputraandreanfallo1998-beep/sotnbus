<section class="routes">
  <div class="container">
    <h2>Rute Populer</h2>
    <ul class="route-list">
      <li>Jakarta &rarr; Yogyakarta</li>
      <li>Bandung &rarr; Surabaya</li>
      <li>Semarang &rarr; Malang</li>
    </ul>
  </div>
</section>
