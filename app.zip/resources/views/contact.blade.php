@extends('layouts.app')

@section('content')
<div class="container py-5">
    <h1>Kontak Kami</h1>
    <p>Silakan hubungi kami melalui email <a href="mailto:support@sotnbus.com">support@sotnbus.com</a> atau nomor WhatsApp 0812-xxxx-xxxx.</p>
</div>
@endsection
