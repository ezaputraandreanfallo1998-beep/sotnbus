<footer class="bg-gray-900 text-gray-300 py-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
            <h3 class="text-white text-lg font-bold mb-3 flex items-center">
                <i class="fas fa-bus mr-2"></i> SOTNBUS.COM
            </h3>
            <p class="text-sm leading-relaxed">Platform pemesanan tiket bus terpercaya dengan rute dan jadwal lengkap di Pulau Jawa.</p>
        </div>
        <div>
            <h4 class="text-white font-semibold mb-2">Perusahaan</h4>
            <ul class="space-y-1 text-sm">
                <li><a href="#" class="hover:underline">Tentang Kami</a></li>
                <li><a href="#" class="hover:underline">Karir</a></li>
                <li><a href="#" class="hover:underline">Blog</a></li>
            </ul>
        </div>
        <div>
            <h4 class="text-white font-semibold mb-2">Layanan</h4>
            <ul class="space-y-1 text-sm">
                <li><a href="#" class="hover:underline">Tiket Bus</a></li>
                <li><a href="<?php echo e(route('promotions.index')); ?>" class="hover:underline">Promo</a></li>
                <li><a href="#" class="hover:underline">Mitra</a></li>
            </ul>
        </div>
        <div>
            <h4 class="text-white font-semibold mb-2">Ikuti Kami</h4>
            <div class="flex space-x-4 mt-2">
                <a href="#" class="hover:text-white"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="hover:text-white"><i class="fab fa-instagram"></i></a>
                <a href="#" class="hover:text-white"><i class="fab fa-twitter"></i></a>
            </div>
        </div>
    </div>
    <div class="text-center text-sm text-gray-500 mt-8">
        &copy; <?php echo e(date('Y')); ?> SOTNBUS.COM. Semua Hak Dilindungi.
    </div>
</footer>
<?php /**PATH D:\laragon\www\sotnbus\resources\views\layouts\partials\footer.blade.php ENDPATH**/ ?>