<!DOCTYPE html>
<html>
<head>
    <title>Detail Rute Bus</title>
</head>
<body>
    <h1>Detail Rute Bus</h1>
    <div>
        <p><strong>Bus:</strong> <?php echo e($route->bus->name); ?></p>
        <p><strong>Asal:</strong> <?php echo e($route->origin->name); ?></p>
        <p><strong>Tujuan:</strong> <?php echo e($route->destination->name); ?></p>
        <p><strong>Berangkat:</strong> <?php echo e($route->formatted_departure_time); ?></p>
        <p><strong>Tiba:</strong> <?php echo e($route->formatted_arrival_time); ?></p>
        <p><strong>Durasi:</strong> <?php echo e($route->duration); ?></p>
        <p><strong>Harga:</strong> Rp <?php echo e(number_format($route->price, 0, ',', '.')); ?></p>
    </div>
    <a href="<?php echo e(route('bus-routes.index')); ?>">Kembali ke Daftar</a>
</body>
</html><?php /**PATH D:\laragon\www\sotnbus\resources\views\bus-routes\show.blade.php ENDPATH**/ ?>