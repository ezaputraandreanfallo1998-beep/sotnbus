<!DOCTYPE html>
<html>
<head>
    <title>Daftar Rute Bus</title>
</head>
<body>
    <h1>Daftar Rute Bus</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Bus</th>
                <th>Asal</th>
                <th>Tujuan</th>
                <th>Berangkat</th>
                <th>Tiba</th>
                <th>Durasi</th>
                <th>Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($route->bus->name); ?></td>
                    <td><?php echo e($route->origin->name); ?></td>
                    <td><?php echo e($route->destination->name); ?></td>
                    <td><?php echo e($route->formatted_departure_time); ?></td>
                    <td><?php echo e($route->formatted_arrival_time); ?></td>
                    <td><?php echo e($route->duration); ?></td>
                    <td>Rp <?php echo e(number_format($route->price, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH D:\laragon\www\sotnbus\resources\views\bus-routes\index.blade.php ENDPATH**/ ?>