

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto mt-10">
    <h2 class="text-2xl font-bold mb-4">Hasil Pencarian</h2>
    <p>Kota Asal: <strong><?php echo e($asal); ?></strong></p>
    <p>Kota Tujuan: <strong><?php echo e($tujuan); ?></strong></p>

    <div class="mt-6 text-gray-600">
        Jadwal perjalanan dan harga tiket akan tampil di sini nanti...
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\sotnbus\resources\views\search\result.blade.php ENDPATH**/ ?>